package TEMA3;

import static TEMA3.ejercicio5.tabla_de_multiplicar;

public class ejercicio6 {

    public static void main(String[] args) {
        int numero=0;
        while (numero<10){
            numero++;
            tabla_de_multiplicar(numero);
        }

    }
}